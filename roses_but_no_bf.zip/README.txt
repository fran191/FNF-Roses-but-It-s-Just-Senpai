Audio is from https://youtu.be/vLKGmxKhc5M, mod was made with permission. 
The .json file was made entirely by me.

. + * Steps for Installation: * + .
1. Put the provided files in the given folders in your FNF folder 
(i.e., files in the "music" & "data" folder go into those respective folders 
in your FNF files).
2. Run the game & enjoy! 
